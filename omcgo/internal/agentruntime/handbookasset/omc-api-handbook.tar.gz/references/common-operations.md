# Common OMC Operations

These are stable, high-frequency fast paths. Call them directly when they match the user intent. Use the local handbook index and selected operation document for every other operation.

## Evidence completeness

- Treat every filtered list as a subset, not a system-wide total. Use a documented summary/count operation or query the complementary states before claiming totals, absence, or overall health.
- Use identifiers returned by list, definition, or discovery operations as the canonical input to dependent calls. Do not replace IDs, metric paths, enum values, or object keys with display labels unless the selected contract explicitly allows names.
- An empty result answers only the selected operation and exact filters. Recheck parameters, time range, identity scope, and the operation document's `relatedOperations` before concluding that data or capability is unavailable.
- When derived, report, or aggregate data is empty but ingestion/file/task metadata proves source data exists, follow related operations toward raw records, counters, task details, or processing status. Explain the evidence boundary if the chain still cannot answer the goal.
- Stop after the evidence is sufficient or after relevant operations repeat the same boundary. Do not invent a complement, infer hidden records, or report a healthy system from one successful subset query.

## Device status totals

Use one of these endpoints, not both, unless their different response shapes are needed:

```bash
node "$CLI" request GET /api/v1/devices/stats '{"operationId":"get.devices.stats","reason":"Read total devices by status"}'
```

Response data contains `counts`. An empty `counts` object means the current user can see no device rows.

```bash
node "$CLI" request GET /api/v1/dashboard/device-status '{"operationId":"get.dashboard.device_status","reason":"Read dashboard device status totals"}'
```

The response is a status-to-count map. An empty map means no visible status totals were recorded.

## Network overview

```bash
node "$CLI" request GET /api/v1/dashboard/summary '{"operationId":"get.dashboard.summary","reason":"Read the network overview"}'
```

Use this for a broad current-state overview. Do not add device, alarm, or topology calls unless the user asks for detail or the summary lacks a required value.

## Device records

```bash
node "$CLI" request GET /api/v1/devices '{"operationId":"get.devices","query":{"page":1,"page_size":20},"reason":"List visible devices"}'
```

Use only when the user needs actual devices, identifiers, names, or filters. Use `/api/v1/devices/stats` for counts.

## Active alarms

```bash
node "$CLI" request GET /api/v1/alarms/active '{"operationId":"get.alarms.active","query":{"page":1,"page_size":20},"reason":"List current active alarms"}'
```

Use for current alarm records. An empty item list means no active alarms are visible under the current filters and permissions.

## Alarm statistics

```bash
node "$CLI" request GET /api/v1/alarms/statistics '{"operationId":"get.alarms.statistics","reason":"Read active alarm totals and severity distribution"}'
```

Use when the user asks for totals, severity distribution, acknowledged state, or a concise alarm summary. Do not also list active alarms unless examples or affected devices are requested.

## Sites

```bash
node "$CLI" request GET /api/v1/sites '{"operationId":"get.sites","query":{"page":1,"page_size":20},"reason":"List site names and locations"}'
```

Use for actual site records. Do not substitute the device list when the user explicitly asks for sites.

## Operations tasks

```bash
node "$CLI" request GET /api/v1/ops/tasks '{"operationId":"get.ops.tasks","query":{"page":1,"page_size":20},"reason":"List current operations tasks"}'
```

Optional filters include `status`, `keyword`, `creator`, and `templateId`. This endpoint covers operations orchestration only; file transfer, upgrades, log collection, MML, and other task domains have separate handbook operations. Read the corresponding operation document before creating or changing a task.

## System runtime information

```bash
node "$CLI" request GET /api/v1/system/info '{"operationId":"get.system.info","reason":"Read OMC runtime information"}'
```

Use for runtime version and system information, not for business health. Use the direct system-license operation below for license questions.

## System license

```bash
node "$CLI" request GET /api/v1/system-license '{"operationId":"get.system_license","reason":"Read the current system license"}'
```

Use this directly for current license status. A `404` response whose message is `no system license configured` means no license is configured; it is not a reason to search for another endpoint.

## Northbound push targets

```bash
node "$CLI" request GET /api/v1/northbound/push/targets '{"operationId":"get.northbound.push.targets","reason":"List northbound push targets and enabled state"}'
```

Use for configured northbound destinations and their enabled state.

## Combining independent reads

When a question explicitly needs multiple independent facts, start all reads in the same shell command and wait for all of them. Keep each output labeled and do not chain dependent calls this way.

```bash
node "$CLI" request GET /api/v1/devices/stats '{"operationId":"get.devices.stats","reason":"Read device totals"}' &
p1=$!
node "$CLI" request GET /api/v1/alarms/statistics '{"operationId":"get.alarms.statistics","reason":"Read alarm totals"}' &
p2=$!
wait "$p1" "$p2"
```
